run TheTrial.exe
Reach the top.
good luck!